# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Gradle documentation](https://docs.gradle.org)
* [Spring Boot Gradle Plugin Reference Guide](https://docs.spring.io/spring-boot/4.0.7/gradle-plugin)
* [Create an OCI image](https://docs.spring.io/spring-boot/4.0.7/gradle-plugin/packaging-oci-image.html)
* [Spring Web Services](https://docs.spring.io/spring-boot/4.0.7/reference/io/webservices.html)
* [Spring Security](https://docs.spring.io/spring-boot/4.0.7/reference/web/spring-security.html)
* [Validation](https://docs.spring.io/spring-boot/4.0.7/reference/io/validation.html)
* [Spring Data JPA](https://docs.spring.io/spring-boot/4.0.7/reference/data/sql.html#data.sql.jpa-and-spring-data)
* [Flyway Migration](https://docs.spring.io/spring-boot/4.0.7/how-to/data-initialization.html#howto.data-initialization.migration-tool.flyway)
* [SpringDoc OpenAPI](https://springdoc.org/)

### Guides
The following guides illustrate how to use some features concretely:

* [Producing a SOAP web service](https://spring.io/guides/gs/producing-web-service/)
* [Securing a Web Application](https://spring.io/guides/gs/securing-web/)
* [Spring Boot and OAuth2](https://spring.io/guides/tutorials/spring-boot-oauth2/)
* [Authenticating a User with LDAP](https://spring.io/guides/gs/authenticating-ldap/)
* [Validation](https://spring.io/guides/gs/validating-form-input/)
* [Accessing Data with JPA](https://spring.io/guides/gs/accessing-data-jpa/)
* [SpringDoc OpenAPI](https://github.com/springdoc/springdoc-openapi-demos/)

### Additional Links
These additional references should also help you:

* [Gradle Build Scans – insights for your project's build](https://scans.gradle.com#gradle)

